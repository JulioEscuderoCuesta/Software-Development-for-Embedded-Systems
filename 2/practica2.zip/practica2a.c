/*
 * File: practica2a.c
 *
 * Description: Muestra el uso de la botonera (por completar)
 *
 * Author:  DSSE
 * Version: 1.0
 *
*/

#include <stdio.h>
#include <unistd.h>
#include "ev3c.h"

#define MAX_SIZE_BYTES              24
#define MAX_ITERATIONS              50
#define SLEEP_DURATION              1       // seconds

/**
 * @brief Check whether a button is pressed
 *
 * This function checks whether a button is pressed and returns the
 * corresponding button id
 *
 * @return the button id pressed, -1 otherwise
 */
int is_button_pressed (void);


int main (void) {

    // Local variables
    int index, button_pressed;
    static const char *BUTTON[] = { "NO_BUTTON", "BUTTON_LEFT", "BUTTON_UP",
                                    "BUTTON_RIGHT", "BUTTON_DOWN", "BUTTON_CENTER", "BUTTON_BACK" };
    char button_text [MAX_SIZE_BYTES]; // char array to store the output string

    // Init devices
    // TODO

    // Main loop
    for (index = 0; index < MAX_ITERATIONS; index++) {
        button_pressed = is_button_pressed();
        if (button_pressed >= 0) {
            sprintf (button_text, "Button: %s", BUTTON [button_pressed + 1]);
            printf ("%s\n", button_text);
        }
        // pseudo-periodic activation
        sleep (SLEEP_DURATION);
    }

    //  Finish & close devices
    printf ("\n*** Finishing button application... ");
    // TODO

    printf ("OK***\n");
    return 0;
}

int is_button_pressed (void) {
    int button_pressed = -1;
    // TODO
    return button_pressed;
}
