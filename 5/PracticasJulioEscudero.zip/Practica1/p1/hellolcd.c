#include <stdio.h>
#include <ev3c_lcd.h>
int main() {

	ev3_init_lcd();
	char hello[50] = "Hello, World!";
	ev3_text_lcd_normal(50,50, hello);
	ev3_quit_lcd();
	return 0;
}
