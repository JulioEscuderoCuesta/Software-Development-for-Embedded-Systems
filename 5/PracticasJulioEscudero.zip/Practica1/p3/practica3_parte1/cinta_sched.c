/*
 * File: practica3.c
 *
 * Description: Muestra el uso de los motores
 *
 * Author:  DSSE
 * Version: 1.0
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include "ev3c.h"
#include <math.h>
#include <unistd.h>
#include <pthread.h>
#include <sched.h>
#include <error_checks.h>
#include <timespec_operations.h>


#define USE_MATH_DEFINES
#define DIAMETER					3.6
#define SHORTDISTANCE					7.4
#define LONGDISTANCE					9.7

#define BELT_MOTOR_PORT             'A'     // Motor ports are named using characters
#define FULL_SPEED_LARGE_MOTOR      900     // units: deg/seg
#define FULL_SPEED_MEDIUM_MOTOR     1200    // units: deg/seg
#define SUSPENSION_TIME             2000    // units: usecs

typedef enum stop_mode_enum {COAST, BRAKE, HOLD} stop_mode;
static char *STOP_MODE_STRING[] = {"coast", "brake", "hold"};

typedef enum commands_enum {RUN_FOREVER, RUN_ABS_POS, RUN_REL_POS, RUN_TIMED, RUN_DIRECT, STOP, RESET} commands;
static char *COMMANDS_STRING[] = {"run-forever", "run-to-abs-pos", "run-to-rel-pos", "run-timed", "run-direct",
                                  "stop", "reset"};

struct thread_params {
    ev3_motor_ptr motors; // List of motors

};

void *ribbon (void *arg) {
	struct thread_params params = *(struct thread_params*)arg;
	ev3_motor_ptr motors = params.motors;
    int index            = 1;    // Loop variable

	// Get the target motor
	ev3_motor_ptr belt_motor = ev3_search_motor_by_port (motors, BELT_MOTOR_PORT);
	if (belt_motor == NULL) {
		printf ("Error on ev3_search_motor_by_port\n");
		pthread_exit(NULL);
	}

	// Init motor
	ev3_reset_motor (belt_motor);
	ev3_open_motor (belt_motor);

	// Motor configuration
	float wheel_distance = M_PI * DIAMETER;
	ev3_stop_action_motor_by_name (belt_motor, STOP_MODE_STRING[HOLD]);
	ev3_set_speed_sp (belt_motor, (15 * belt_motor->max_speed) / 100);
	ev3_set_position (belt_motor, 0);
	int position = 0;

	while (index <= 3) { // Main loop
		if(index == 2)
			position = position + 360 * LONGDISTANCE / wheel_distance;
		else
			position = position + 360 * SHORTDISTANCE / wheel_distance;
		ev3_set_position_sp(belt_motor, position);
		ev3_command_motor_by_name (belt_motor, COMMANDS_STRING[RUN_ABS_POS]); // Action!
		index++;
		while ((ev3_motor_state (belt_motor) & MOTOR_RUNNING)); // Wait until motor action is complete
		//ev3_command_motor_by_name(belt_motor, COMMANDS_STRING[STOP]);
		sleep (1);
		printf ("Current position %d (degrees)\n", ev3_get_position (belt_motor));

	}

	//Let's reset and close the motors
	ev3_set_position_sp (belt_motor, 0);
	ev3_command_motor_by_name (belt_motor, COMMANDS_STRING[RUN_ABS_POS]);
	usleep (SUSPENSION_TIME);
	while ((ev3_motor_state (belt_motor) & MOTOR_RUNNING));

	printf ("Final position %d (degrees)\n", ev3_get_position (belt_motor));
	ev3_reset_motor (belt_motor);
	ev3_delete_motors (motors);
	pthread_exit(0);
}


int main (void) {
	//Main Thread
    pthread_attr_t attr;
    pthread_t main_thread;
    struct thread_params thread_p;
    struct sched_param sch_param;

    CHK ( pthread_attr_init(&attr));
    CHK ( pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED));
    CHK ( pthread_attr_setschedpolicy(&attr, SCHED_FIFO));
    sch_param.sched_priority = 20;
    CHK ( pthread_attr_setschedparam(&attr, &sch_param));
    thread_p.motors = ev3_load_motors(); // Loading all motors

    if (thread_p.motors == NULL) {
	   printf ("Error on ev3_load_motors\n");
	   return EXIT_FAILURE;
    }

    //Create Thread
    CHK (pthread_create(&main_thread, &attr, ribbon, &thread_p));
    CHK ( pthread_join(main_thread, NULL));
    CHK (pthread_attr_destroy(&attr));
    return 0;

}
