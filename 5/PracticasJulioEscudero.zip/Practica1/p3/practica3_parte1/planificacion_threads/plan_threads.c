#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <stdlib.h>
#include <sched.h>
#include "error_checks.h"
#include "timespec_operations.h"

//datos transferidos a cada thread como argumento
struct thread_params {
	float execution_time;
	struct timespec period;
	int id; //identificador de la tarea
};

void * periodic (void *arg) {
	struct thread_params params = *(struct thread_params*)arg;
	struct timespec next_time;
	//lee la hora de la primera activación de la tarea
	clock_gettime(CLOCK_MONOTONIC, &next_time);

	//lazo que se ejecuta periódicamente
	while(1) {
		printf("Thread %d empieza ", params.id);
		sleep(5);
		printf("Thread %d acaba ", params.id);


		//espera al próximo periodo
		incr_timespec(&next_time, &params.period); // sumo el periodo a la activación previa
		CHK( clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next_time, NULL));
	}

	pthread_exit(NULL);

}

int main() {
	printf("hola");
	pthread_attr_t attr;
	pthread_t t1, t2;
	struct thread_params t1_params, t2_params;
	struct sched_param sch_param;

	//Crea el objeto de atributos
	CHK( pthread_attr_init (&attr));

	//Asigna cada atributo (no olvidar el taributo inheristsched)
	CHK( pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED));
	CHK( pthread_attr_setschedpolicy(&attr, SCHED_FIFO));
	sch_param.sched_priority = 20;
	CHK(pthread_attr_setschedparam(&attr, &sch_param));

	//Preapara los argumentos del primer thread
	t1_params.period.tv_sec = 2; t1_params.period.tv_nsec=0;
	t1_params.execution_time = 1.0;
	t1_params.id = 1;

	CHK( pthread_create(&t1, &attr, periodic, &t1_params)); //crea primer thread

	//Cambia la prio en los atributos para crear el segundo thread
	sch_param.sched_priority = sched_get_priority_max(SCHED_FIFO) - 6;
	CHK( pthread_attr_setschedparam(&attr, &sch_param));

	//Prepara los argumentos del segundo thread
	t2_params.period.tv_sec = 7; t2_params.period.tv_nsec = 0;
	t2_params.execution_time = 4.0;
	t2_params.id = 2;
	printf("antes de crear hilo");
	CHK( pthread_create(&t2, &attr, periodic, &t2_params)); //crea el segundo thread

	CHK( pthread_join(t1, NULL)); //Permite a los thread ejecutar para siempre

	return 0;
}
