#!/bin/bash -u
# Script_name     : rtinfo_threads
# Author          : DSSE
# Description     : Show threads' info for a given process
# Version         : v1.0

# Main
: ${1?"Usage: $0 PROCESS_NAME"}
#  Script exits here if command-line parameter absent

PROCESS_NAME="$1"
PROCESS_PID=""
DATE=$(date)

echo "Looking for ${PROCESS_NAME} ($DATE)"
while [ "$PROCESS_PID" = "" ]
do
    PROCESS_PID=$(pgrep ${PROCESS_NAME})
    sleep 0.2
done

echo ""
echo "### Threads info for ${PROCESS_NAME} (pid ${PROCESS_PID}) "
echo ""

echo " - POSIX priorities and policies:"
chrt -a -p ${PROCESS_PID}
echo ""
echo " - Linux priorities and thread names (CMD col if any):"
ps -cT -p ${PROCESS_PID}
echo ""
