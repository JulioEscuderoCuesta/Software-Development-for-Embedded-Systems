#include <stdio.h>
#include <ev3c.h>
#include <stdbool.h>
#include <math.h>

#define ALPHA			0.3
#define COLOR_SENSOR_NOT_AVAILABLE  -1
#define COLOR_SENSOR_PORT            3

#define MAX_ITERATIONS              20
#define SLEEP_DURATION              1       // seconds

float lowpass_filter(float, float);

typedef enum color_command_enum
{
    COL_REFLECT = 0, COL_AMBIENT = 1, COL_COLOR = 2
} color_command;

int main (void) {

    ev3_sensor_ptr sensors       = NULL; //  List of available sensors
    ev3_sensor_ptr color_sensor  = NULL;

    int new_data, old_data;
    float filter;
	int filter_rounded;
    char *mode;

    //Initiate leds
    ev3_init_led();

    // Loading all sensors
    sensors = ev3_load_sensors();
    if (sensors == NULL) {
        printf ("Error on ev3_load_sensors\n");
        return COLOR_SENSOR_NOT_AVAILABLE;
    }

    // Get color sensor by port
    color_sensor = ev3_search_sensor_by_port (sensors, COLOR_SENSOR_PORT);
    if (color_sensor == NULL) {
        printf ("Error on ev3_search_sensor_by_port\n");
        return COLOR_SENSOR_NOT_AVAILABLE;
    }

    // Init sensor
    color_sensor = ev3_open_sensor (color_sensor);
    if (color_sensor == NULL) {
        printf ("Error on ev3_open_sensor\n");
        return COLOR_SENSOR_NOT_AVAILABLE;
    }

    // Set mode
    ev3_mode_sensor (color_sensor, COL_AMBIENT);
    mode = color_sensor->modes[color_sensor->mode];
    printf ("Color mode enabled: %s\n", mode);

    do {
    	ev3_set_led(RIGHT_LED,GREEN_LED,0);
		ev3_set_led(LEFT_LED,GREEN_LED,0);
		ev3_set_led(RIGHT_LED,RED_LED,0);
		ev3_set_led(LEFT_LED,RED_LED,0);
        ev3_update_sensor_val (color_sensor);

        new_data = color_sensor->val_data[0].s32;
        printf ("new data = %d\n", new_data);


        filter = lowpass_filter(new_data, old_data);
        printf ("filter = %f\n", filter);
        filter_rounded = floor(filter);
        printf ("filter_rounded = %d\n", filter_rounded);

        if(filter_rounded==5) {
        	ev3_set_led(LEFT_LED, RED_LED, 255);
        	ev3_set_led(RIGHT_LED, RED_LED, 255);

        }
        else if(filter_rounded==3) {
        	ev3_set_led(LEFT_LED, GREEN_LED, 255);
            ev3_set_led(RIGHT_LED, GREEN_LED, 255);


        }
        else if(filter_rounded==4) {
			ev3_set_led(LEFT_LED, GREEN_LED, 255);
			ev3_set_led(RIGHT_LED, GREEN_LED, 255);
			ev3_set_led(LEFT_LED, RED_LED, 255);
			ev3_set_led(RIGHT_LED, RED_LED, 255);

		}
        sleep (SLEEP_DURATION);
    } while(ev3_button_pressed(BUTTON_BACK) != 1);

    //  Finish & close devices
    printf ("\n*** Finishing color sensor application... OK***\n");
    ev3_delete_sensors (sensors);
    ev3_quit_led();
    ev3_quit_lcd();

    return 0;
}

float lowpass_filter(float new_data, float old_data) {
	static bool first_time = true;

	if(first_time) {
		old_data = new_data;
		first_time = false;
	}

	float result = old_data + (ALPHA* (new_data - old_data));
	return result;
}
