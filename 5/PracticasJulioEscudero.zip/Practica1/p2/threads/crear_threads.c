#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <error_checks.h>


//Thread que pone pseudo-periódicamente un mensaje en pantalla
//el periodo se pasa como parámetro

void *periodic (void *arg) {
	int period;

	period = *((int*) arg);
	while (1) {
		printf("En el thread con periodo %d\n", period);
		sleep(period);
	}
}

//Programa principal que crea dos threads pseudo-periódicos
int main() {
	pthread_t th1, th2;
	pthread_attr_t attr;
	int period1 = 2;
	int period2 = 3;
	//Crea el objeto de atributos para crear threads independientes
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	//Crea los threads
	 pthread_create(&th1, &attr, periodic, &period1);
	 pthread_create(&th2, &attr, periodic, &period2);

	//Les deja ejecutando un rato y luego termina
	sleep(30);
	printf("thread main terminado\n" );
	pthread_attr_destroy(&attr);
	exit (0);

}

