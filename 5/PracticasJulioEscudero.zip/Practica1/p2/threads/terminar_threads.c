#include <stdio.h>
#include <pthread.h>
#include <error_checks.h>

#define MAX 50000
#define MITAD (MAX/2)

typedef struct {
	int *ar;
	long n;

} subarray_t;

void *incrementar (void *arg) {
	long i;
	subarray_t * subarray = ((subarray_t *)arg);
	for(i=0; i< subarray->n; i++ ){
		subarray->ar[i]++;
	}
	return NULL;
}

int main() {
	int ar [MAX] = {0}; //Inicializa los elementos a 0
	pthread_t th1, th2;
	subarray_t sb1, sb2;
	int suma=0, i;

	//Crea los threads
	sb1.ar = &ar[0]; sb1.n = MITAD; //Primera mitad del array
	pthread_create(&th1, NULL, incrementar, &sb1);

	sb2.ar = &ar[MITAD]; sb2.n = MITAD; //Segunda mitad del array
	pthread_create(&th2, NULL, incrementar, &sb2);

	//Sincronización de espera y finalización
	pthread_join(th1, NULL);
	pthread_join(th2, NULL);
	printf("Ambos threads han finalizado\n");
	for(i=0; i<MAX;i++) //muestra los resultados
		suma=suma+ar[i];
	printf("Suma=%d\n", suma);
	return 0;

}
