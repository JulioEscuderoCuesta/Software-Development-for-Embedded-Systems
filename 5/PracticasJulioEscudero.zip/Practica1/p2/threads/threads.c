/*
 * File: threads.c
 *
 * Description: Ejemplo sencillo de creación de threads en C - POSIX
 *
 * Author:  Intro_SW
 * Version: 0.1
 *
 */

#include <stdio.h>
#include <stdlib.h>

#define THREADS_NUMBER  8

const char *messages[THREADS_NUMBER] = {"English: Hello World!", 
                                        "French: Bonjour, le monde!",
                                        "Spanish: Hola mundo!",
                                        "German: Guten Tag, Welt!",
                                        "Russian: Zdravstvuyte, mir!",
                                        "Japan: Sekai e konnichiwa!",
                                        "Latin: Orbis, te saluto!",
                                        "Portuguese: Ola mundo"
                                       };
/*
 * La funcion print_hello contiene el codigo a ejecutar por cada thread   
 */
void *print_hello (void *args)
{
	int s;

	s = *((int*)args);

    for(int i = 0; i< sizeof(*messages);i++) {
    	if(i == s)
    		printf("%s", messages[i]);
    }
    return NULL;
}
/*
 * Este es el código que ejecuta el thread principal   
*/
int main (int argc, char *argv[])
{
    // TODO
	pthread_t main_th, th1, th2, th3, th4, th5, th6, th7, th8;
	int t1 = 1; int t2 = 2; int t3 = 3; int t4 = 4; int t5 = 5; int t6 = 6; int t7 = 7; int t8 = 8;

	pthread_create(&th1, NULL, print_hello, &t1);
	pthread_create(&th2, NULL, print_hello, &t2);
	pthread_create(&th3, NULL, print_hello, &t3);
	pthread_create(&th4, NULL, print_hello, &t4);
	pthread_create(&th5, NULL, print_hello, &t5);
	pthread_create(&th6, NULL, print_hello, &t6);
	pthread_create(&th7, NULL, print_hello, &t7);
	pthread_create(&th8, NULL, print_hello, &t8);
	pthread_join(th8, NULL);
	pthread_join(th2, NULL);
	pthread_join(th3, NULL);
	pthread_join(th4, NULL);
	pthread_join(th5, NULL);
	pthread_join(th6, NULL);
	pthread_join(th7, NULL);
	pthread_join(th1, NULL);

    printf ("App finished.\n");  // Ultimo texto en salir por pantalla
    return 0;
}
