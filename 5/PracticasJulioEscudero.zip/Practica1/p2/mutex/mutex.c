#include <pthread.h>
#include <stdio.h>

struct shared_data {
	pthread_mutex_t mutex;
	int a,b,c,i;
} data;


//Este thread incrementa a,b y c 20 veces
void *incrementer (void *arg) {
	for(data.i=1; data.i<20; data.i++) {
		pthread_mutex_lock(&data.mutex);
		data.a++;
		data.b++;
		data.c++;
		pthread_mutex_unlock(&data.mutex);
	}
	return NULL;
}

void *reporter (void *arg) {
	do {
		pthread_mutex_lock(&data.mutex);
		printf("a=%d, b=%d, c=%d", data.a, data.b, data.c);
		pthread_mutex_unlock(&data.mutex);
	} while(data.i<20);
	return NULL;
}

//Programa principal: crea el mutex y los threads
int main() {
	pthread_mutexattr_t mutexattr;
	pthread_t t1,t2;
	struct sched_param sch_param;
	pthread_attr_t attr;

	data.a=0; data.b=0; data.c=0; data.i=0;

	// crea el mutex
	pthread_mutexattr_init (&mutexattr);
	pthread_mutexattr_setprotocol (&mutexattr, PTHREAD_PRIO_PROTECT);
	pthread_mutexattr_setprioceiling(&mutexattr, sched_get_priority_min(SCHED_RR));
	pthread_mutex_init(&data.mutex, &mutexattr);
	// Prepara atributos para planificación round-robin
	pthread_attr_init(&attr);
	pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&attr, SCHED_RR);
	sch_param.sched_priority = sched_get_priority_min(SCHED_RR);
	pthread_attr_setschedparam(&attr, &sch_param);
	// crea los threads
	pthread_create(&t1,&attr,incrementer,NULL);
	pthread_create(&t2,&attr,reporter,NULL);
	// espera a que acaben
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	return 0;
}
