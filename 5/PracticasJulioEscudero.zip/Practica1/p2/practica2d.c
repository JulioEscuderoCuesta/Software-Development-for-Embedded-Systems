#include <pthread.h>
#include <stdio.h>
#include <ev3c.h>
#include <unistd.h>
#include <stdbool.h>
#include <pthread.h>
#include <math.h>
#include "ev3c.h"

#define MAX_SIZE_BYTES              24
#define MAX_ITERATIONS_BUTTONS      50
#define SLEEP_DURATION_BUTTONS              1       // seconds

#define ALPHA			0.3
#define COLOR_SENSOR_NOT_AVAILABLE  -1
#define COLOR_SENSOR_PORT            3

#define MAX_ITERATIONS_SENSORS      50
#define SLEEP_DURATION_SENSOR              1    // seconds

#define SLEEP_DURATION_REPORTER              1       // seconds


//void buttons_part();
void is_button_pressed (void);
//void sensors_part();
float lowpass_filter(float,float);

static const char *BUTTON[] = { "NO_BUTTON", "BUTTON_LEFT", "BUTTON_UP",
                                    "BUTTON_RIGHT", "BUTTON_DOWN", "BUTTON_CENTER", "BUTTON_BACK" };

typedef enum color_command_enum
{
    COL_REFLECT = 0, COL_AMBIENT = 1, COL_COLOR = 2
} color_command;

struct shared_data {
	pthread_mutex_t mutex;
	int button_pressed,i;
	float filter;
	char *mode;
} data;

void *sensors_part() {

	ev3_sensor_ptr sensors       = NULL; //  List of available sensors
    ev3_sensor_ptr color_sensor  = NULL;

    int new_data, old_data;

    //Initiate leds
    ev3_init_led();

    // Loading all sensors
    sensors = ev3_load_sensors();
    if (sensors == NULL) {
        printf ("Error on ev3_load_sensors\n");
        return COLOR_SENSOR_NOT_AVAILABLE;
    }

    // Get color sensor by port
    color_sensor = ev3_search_sensor_by_port (sensors, COLOR_SENSOR_PORT);
    if (color_sensor == NULL) {
        printf ("Error on ev3_search_sensor_by_port\n");
        return COLOR_SENSOR_NOT_AVAILABLE;
    }

    // Init sensor
    color_sensor = ev3_open_sensor (color_sensor);
    if (color_sensor == NULL) {
        printf ("Error on ev3_open_sensor\n");
        return COLOR_SENSOR_NOT_AVAILABLE;
    }

    // Set mode
    ev3_mode_sensor (color_sensor, COL_COLOR);
	pthread_mutex_lock(&data.mutex);
    data.mode = color_sensor->modes[color_sensor->mode];
	pthread_mutex_unlock(&data.mutex);
	float filter_rounded;

    do {
        ev3_update_sensor_val (color_sensor);
        new_data = color_sensor->val_data[0].s32;
    	pthread_mutex_lock(&data.mutex);
        data.filter = lowpass_filter(new_data, old_data);
        filter_rounded = data.filter;
    	pthread_mutex_unlock(&data.mutex);

    	if(filter_rounded==5) {
			ev3_set_led(LEFT_LED, RED_LED, 255);
			ev3_set_led(RIGHT_LED, RED_LED, 255);

		}
		else if(filter_rounded==3) {
			ev3_set_led(LEFT_LED, GREEN_LED, 255);
			ev3_set_led(RIGHT_LED, GREEN_LED, 255);


		}
		else if(filter_rounded==4) {
			ev3_set_led(LEFT_LED, GREEN_LED, 255);
			ev3_set_led(RIGHT_LED, GREEN_LED, 255);
			ev3_set_led(LEFT_LED, RED_LED, 255);
			ev3_set_led(RIGHT_LED, RED_LED, 255);

		}
        old_data = new_data;
        sleep (SLEEP_DURATION_SENSOR);
    } while(data.button_pressed != 5);

    //  Finish & close devices
    printf ("\n*** Finishing color sensor application... OK***\n");
    ev3_delete_sensors (sensors);
    ev3_quit_led();
    return NULL;
}


void *buttons_part() {
	    // Init devices
	    ev3_init_button();

	    // Main loop
	    do {
	    	is_button_pressed();
	        // pseudo-periodic activation
	        sleep (SLEEP_DURATION_BUTTONS);
	    } while(data.button_pressed!=5);

	    //  Finish & close devices
	    printf ("\n*** Finishing button application... ");
	    ev3_quit_button();

	    printf ("OK***\n");
	    return NULL;
}

void *reporter_part() {
    char button_text [MAX_SIZE_BYTES]; // char array to store the output string
    char mode_text [MAX_SIZE_BYTES]; // char array to store the output string
    char filter_text [MAX_SIZE_BYTES]; // char array to store the output string
    int filter_rounded;
    ev3_init_lcd();

    //printf ("Color mode enabled: %d\n", data.mode);

    do {
    	pthread_mutex_lock(&data.mutex);
    	if (data.button_pressed >= 0) {
			sprintf (button_text, "Button: %s", BUTTON [data.button_pressed + 1]);
			ev3_text_lcd_normal(25,60, button_text);

		}
    	else if(data.button_pressed < 1) {
			sprintf (button_text, "Button: %s", BUTTON [0]);
			ev3_text_lcd_normal(25,60, button_text);
		}

    	pthread_mutex_unlock(&data.mutex);
    	sleep(SLEEP_DURATION_REPORTER);
    	ev3_clear_lcd();

    	pthread_mutex_lock(&data.mutex);
		sprintf (mode_text, "Sensor mode: %s", data.mode);
		ev3_text_lcd_normal(25,60, mode_text);
    	pthread_mutex_unlock(&data.mutex);
    	sleep(SLEEP_DURATION_REPORTER);

    	ev3_clear_lcd();

    	pthread_mutex_lock(&data.mutex);
    	filter_rounded = round(data.filter);
		sprintf (filter_text, "Sensor data: %d", filter_rounded);
		ev3_text_lcd_normal(25,60, filter_text);
    	pthread_mutex_unlock(&data.mutex);
    	sleep(SLEEP_DURATION_REPORTER);

    	ev3_clear_lcd();
    	sleep(SLEEP_DURATION_REPORTER);
    } while(data.button_pressed!=5);

    printf ("\n*** Finishing reporter application... OK");
	return NULL;

}

int main (void) {

	//Threads
	pthread_t button_thread, sensor_thread, reporter_thread;
	//Mutex
	pthread_mutexattr_t mutexattr;

	data.button_pressed = -1;


	// crea el mutex
	pthread_mutexattr_init (&mutexattr);
	pthread_mutexattr_setprotocol (&mutexattr, PTHREAD_PRIO_PROTECT);
	pthread_mutexattr_setprioceiling(&mutexattr, sched_get_priority_min(SCHED_RR));
	pthread_mutex_init(&data.mutex, &mutexattr);

	pthread_create(&button_thread, NULL, buttons_part, NULL);
	pthread_create(&sensor_thread, NULL, sensors_part, NULL);
	pthread_create(&reporter_thread, NULL, reporter_part, NULL);

	pthread_join(button_thread, NULL);
	pthread_join(sensor_thread, NULL);
	pthread_join(reporter_thread, NULL);
	printf("hilos terminados");
    return 0;
}




void is_button_pressed (void) {
    for(int i = 0; i <= 5; i++) {
    	if(ev3_button_pressed(i)) {
    		pthread_mutex_lock(&data.mutex);
    		data.button_pressed = i;
    		pthread_mutex_unlock(&data.mutex);
    	}
    }
}


float lowpass_filter(float new_data, float old_data) {
	static bool first_time = true;
	if(first_time) {
		old_data = new_data;
		first_time = false;
	}
	float result = old_data + (ALPHA* (new_data - old_data));
	return result;
}


