/*
 *
 * Description: Práctica final de la asignatura Desarrollo de Software para Sistemas Empotrados
 *
 * Author:  Julio Escudero Cuesta
 * Version: 0.1
 *
 */

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <math.h>
#include <ev3c.h>
#include <stdbool.h>
#include <time.h>
#include <error_checks.h>
#include <timespec_operations.h>

//Max size of string array
#define MAX_SIZE_BYTES              50

//Constants to define robot speed, forward and backward. Also little adjustment due to the weight of the catapult.
//Catapult trigger speed and how often screen updates.
#define LOW_SPEED						150
#define MEDIUM_SPEED					200
#define HIGH_SPEED						300
#define ADJUSTMENT						20
#define SPEED_REVERSE_MAIN_MOTOR		-300
#define SPEED_REVERSE_SECONDARY_MOTOR	-100
#define SPEED_REVERSE_CATAPULT			0.05
#define SCREEN_UPDATE_FREQUENCY			1

//Ports for motors and the sensor.
#define ULTRASONIC_SENSOR_PORT 	 2
#define RIGHT_MOTOR_PORT		'A'
#define LEFT_MOTOR_PORT		 	'B'
#define CATAPULT_MOTOR_PORT		'D'

//Different stop and run modes
typedef enum stop_mode_enum {COAST, BRAKE, HOLD} stop_mode;
static char *STOP_MODE_STRING[] = {"coast", "brake", "hold"};

typedef enum commands_enum {RUN_FOREVER, RUN_ABS_POS, RUN_REL_POS, RUN_TIMED, RUN_DIRECT, STOP, RESET} commands;
static char *COMMANDS_STRING[] = {"run-forever", "run-to-abs-pos", "run-to-rel-pos", "run-timed", "run-direct",
                                  "stop", "reset"};

//Catapult state
enum catapult_state {EMPTY, CHARGING, CHARGED};

//Prototypes
int is_button_pressed(void);
void update_screen(bool, bool, enum catapult_state);
void display_main_menu(void);
void display_exit_button(void);
void display_button_attack_mode(bool);
void display_button_catapult(enum catapult_state);
int get_random_num(void);

//Shared data among all threads
struct shared_data {
	pthread_mutex_t mutex;
	bool start;
	bool object_in_front;
	int last_button_pressed;
	bool attack_mode;
	enum catapult_state catapult_state;
} shared_data;

//Motor thread parameters
struct motors_thread_params {
    ev3_motor_ptr right_motor;
    ev3_motor_ptr left_motor;
    ev3_motor_ptr catapult_motor;
};

//Sensor thread parameters
struct sensor_thread_params {
    ev3_sensor_ptr ultrasonic_sensor;
};

/**
 * Screen thread. It takes the data from the shared data and displays it on the screen.
 */
void *screen(void *arg) {
	struct timespec time;
	struct timespec next_time;
	int last_button_pressed;
	bool object_in_front = false;
	bool attack_mode = false;
	enum catapult_state current_state = CHARGED;

	time = *(struct timespec*) arg;

	//Init screen and clean it.
	ev3_init_lcd();
	ev3_clear_lcd();

	//Display main menu
	display_main_menu();

	pthread_mutex_lock(&shared_data.mutex);
	last_button_pressed = shared_data.last_button_pressed;
	pthread_mutex_unlock(&shared_data.mutex);

	clock_gettime(CLOCK_MONOTONIC, &next_time);

	while(last_button_pressed != BUTTON_BACK) {
		pthread_mutex_lock(&shared_data.mutex);
		object_in_front = shared_data.object_in_front;
		attack_mode = shared_data.attack_mode;
		current_state = shared_data.catapult_state;
		pthread_mutex_unlock(&shared_data.mutex);
		update_screen(object_in_front, attack_mode, current_state);

		pthread_mutex_lock(&shared_data.mutex);
		last_button_pressed = shared_data.last_button_pressed;
		pthread_mutex_unlock(&shared_data.mutex);

		//Wait a bit before calling update again. Otherwise, it gets blurred
		incr_timespec(&next_time, &time);
		CHK (clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next_time, NULL));
	}
	ev3_quit_lcd();
	return NULL;

}

/**
 * Button thread. It saves buttons pressed
 */
void *buttons(void *arg) {
	int last_button_pressed;

	//Init devices
	ev3_init_button();

	//If last button pressed was BUTTON_BACK, stop and return
	while(last_button_pressed != BUTTON_BACK){
		last_button_pressed = is_button_pressed();
		pthread_mutex_lock(&shared_data.mutex);
		shared_data.last_button_pressed = last_button_pressed;
		pthread_mutex_unlock(&shared_data.mutex);
	}
    ev3_quit_button();
	return NULL;
}

/**
 * Changes the state of the robot. It indicates whether attack mode is on and whether the catapult is ready, being charged or empty.
 */
void *state(void *arg) {
	int last_button_pressed;
	bool attack_mode = false;
	enum catapult_state current_state = CHARGED;

	pthread_mutex_lock(&shared_data.mutex);
	last_button_pressed = shared_data.last_button_pressed;
	pthread_mutex_unlock(&shared_data.mutex);

	while(last_button_pressed != BUTTON_BACK) {
		pthread_mutex_lock(&shared_data.mutex);
		attack_mode = shared_data.attack_mode;
		current_state = shared_data.catapult_state;
		pthread_mutex_unlock(&shared_data.mutex);

		//It changes attack mode if catapult is not being reloaded
		if(current_state != CHARGING) {
			if(last_button_pressed == BUTTON_DOWN) {
				//Attack mode is on. Now should be off.
				if(attack_mode) {
					pthread_mutex_lock(&shared_data.mutex);
					shared_data.attack_mode = false;
					pthread_mutex_unlock(&shared_data.mutex);
				}
				//Attack mode is off. Now should be on.
				else {
					pthread_mutex_lock(&shared_data.mutex);
					shared_data.attack_mode = true;
					pthread_mutex_unlock(&shared_data.mutex);

				}
			}
		}
		pthread_mutex_lock(&shared_data.mutex);
		last_button_pressed = shared_data.last_button_pressed;
		pthread_mutex_unlock(&shared_data.mutex);
	}
	return NULL;
}

/**
 * Motors thread.
 *
 * It controls the movement of the robot (forward and backward), shifts between different gears and handles the catapult trigger.
 */
void *motors(void *arg) {
	bool object_in_front = false;
	int last_button_pressed, speed_before_stopping;
	bool attack_mode = false;
	enum catapult_state current_state = CHARGED;
	bool charging_catapult = false;

	struct motors_thread_params params = *(struct motors_thread_params*)arg;
	ev3_motor_ptr left_motor = params.left_motor;
	ev3_motor_ptr right_motor = params.right_motor;
	ev3_motor_ptr catapult_motor = params.catapult_motor;

	//Reset motors
	ev3_reset_motor (left_motor);
	ev3_reset_motor (right_motor);
	ev3_reset_motor (catapult_motor);

	//Open motors
	ev3_open_motor (left_motor);
	ev3_open_motor (right_motor);
	ev3_open_motor (catapult_motor);

	//Motors configuration
	ev3_stop_action_motor_by_name (left_motor, STOP_MODE_STRING[COAST]);
	ev3_stop_action_motor_by_name (right_motor, STOP_MODE_STRING[COAST]);
	ev3_stop_action_motor_by_name (catapult_motor, STOP_MODE_STRING[HOLD]);

	//Set speed to MEDIUM_SPEED by default
	ev3_set_speed_sp (right_motor, MEDIUM_SPEED);
	ev3_set_speed_sp (left_motor, MEDIUM_SPEED + ADJUSTMENT);

	pthread_mutex_lock(&shared_data.mutex);
	last_button_pressed = shared_data.last_button_pressed;
	pthread_mutex_unlock(&shared_data.mutex);
	while(last_button_pressed != BUTTON_BACK) {
		//Shift gear
		switch(last_button_pressed)
		{
			case BUTTON_RIGHT:
				ev3_set_speed_sp (right_motor, HIGH_SPEED);
				ev3_set_speed_sp (left_motor, HIGH_SPEED + ADJUSTMENT);
				break;
			case BUTTON_CENTER:
				ev3_set_speed_sp (right_motor, MEDIUM_SPEED);
				ev3_set_speed_sp (left_motor, MEDIUM_SPEED + ADJUSTMENT);
				break;
			case BUTTON_LEFT:
				ev3_set_speed_sp (right_motor, LOW_SPEED);
				ev3_set_speed_sp (left_motor, LOW_SPEED + ADJUSTMENT);
				break;
			case BUTTON_UP:
				pthread_mutex_lock(&shared_data.mutex);
				current_state = shared_data.catapult_state;
				pthread_mutex_unlock(&shared_data.mutex);

				//Catapult is empty and BUTTON_UP was pressed. Means user wants to reload it.
				if(current_state == EMPTY) {
					//Stop the movement
					ev3_command_motor_by_name(left_motor, COMMANDS_STRING[STOP]);
					ev3_command_motor_by_name(right_motor, COMMANDS_STRING[STOP]);
					pthread_mutex_lock(&shared_data.mutex);
					shared_data.catapult_state = CHARGING;
					pthread_mutex_unlock(&shared_data.mutex);
					//And indicate catapult is being charged
					charging_catapult = true;

					//Wait to update last button pressed
					sleep(2);
				}
				break;
		}

		if(charging_catapult) {
			pthread_mutex_lock(&shared_data.mutex);
			last_button_pressed = shared_data.last_button_pressed;
			pthread_mutex_unlock(&shared_data.mutex);
			//Wait until catapult is reloaded
			while(last_button_pressed != BUTTON_UP) {
				//If BUTTON_CENTER is pressed, it means catapult has been reloaded. Pull the trigger down
				if(last_button_pressed == BUTTON_CENTER) {
					ev3_set_speed_sp(catapult_motor, catapult_motor->max_speed * SPEED_REVERSE_CATAPULT);
					ev3_set_position_sp(catapult_motor, ev3_get_position_sp(catapult_motor) - 150);
					ev3_command_motor_by_name(catapult_motor, COMMANDS_STRING[RUN_ABS_POS]);
					//Wait until the trigger is put down
					while ((ev3_motor_state (catapult_motor) & MOTOR_RUNNING));
					sleep(1);
					pthread_mutex_lock(&shared_data.mutex);
					shared_data.catapult_state = CHARGED;
					pthread_mutex_unlock(&shared_data.mutex);
				}
				pthread_mutex_lock(&shared_data.mutex);
				last_button_pressed = shared_data.last_button_pressed;
				pthread_mutex_unlock(&shared_data.mutex);
			}
			//Do not start running immediately
			sleep(1);
			//Finished reloading catapult
			charging_catapult = false;
		}
		//Start moving
		ev3_command_motor_by_name (left_motor, COMMANDS_STRING[RUN_FOREVER]);
		ev3_command_motor_by_name (right_motor, COMMANDS_STRING[RUN_FOREVER]);

		pthread_mutex_lock(&shared_data.mutex);
		object_in_front = shared_data.object_in_front;
		pthread_mutex_unlock(&shared_data.mutex);

		//Something is ahead. Need to stop the movement.
		if(object_in_front) {
			//Save current speed before stopping
			speed_before_stopping = ev3_get_speed_sp(right_motor);

			//Stop the movement
			ev3_command_motor_by_name(left_motor, COMMANDS_STRING[STOP]);
			ev3_command_motor_by_name(right_motor, COMMANDS_STRING[STOP]);
			sleep(1);

			pthread_mutex_lock(&shared_data.mutex);
			attack_mode = shared_data.attack_mode;
			current_state = shared_data.catapult_state;
			pthread_mutex_unlock(&shared_data.mutex);

			//Attack mode is on. Prepare for action.
			if(attack_mode && current_state == CHARGED) {
				//Release the catapult.
				ev3_set_speed_sp(catapult_motor, catapult_motor->max_speed);
				ev3_set_position(catapult_motor, 0);
				ev3_set_position_sp(catapult_motor, ev3_get_position(catapult_motor) + 120);
				ev3_command_motor_by_name(catapult_motor, COMMANDS_STRING[RUN_ABS_POS]);
				while ((ev3_motor_state (catapult_motor) & MOTOR_RUNNING));
				sleep(1);
				//Catapult has been used. Now it is empty.
				pthread_mutex_lock(&shared_data.mutex);
				shared_data.catapult_state = EMPTY;
				pthread_mutex_unlock(&shared_data.mutex);
			} else { //Attack mode is off. Change path
				//Reverse to left or to right
				if(get_random_num()==1){
					ev3_set_speed_sp (left_motor, SPEED_REVERSE_MAIN_MOTOR);
					ev3_set_speed_sp (right_motor, SPEED_REVERSE_SECONDARY_MOTOR);
					ev3_set_position_sp(left_motor, ev3_get_position(left_motor) - 2000);
					//If only left motor moves, it turns out weird
					ev3_command_motor_by_name(left_motor, COMMANDS_STRING[RUN_ABS_POS]);
					ev3_command_motor_by_name(right_motor, COMMANDS_STRING[RUN_FOREVER]);
					//Wait until the robot is set to continue running
					while ((ev3_motor_state (left_motor) & MOTOR_RUNNING));
				}
				else{
					ev3_set_speed_sp (left_motor, SPEED_REVERSE_SECONDARY_MOTOR);
					ev3_set_speed_sp (right_motor, SPEED_REVERSE_MAIN_MOTOR);
					ev3_set_position_sp(right_motor, ev3_get_position(right_motor) - 2000);
					ev3_command_motor_by_name(right_motor, COMMANDS_STRING[RUN_ABS_POS]);
					ev3_command_motor_by_name(left_motor, COMMANDS_STRING[RUN_FOREVER]);
					//Wait until the robot is set to continue running
					while ((ev3_motor_state (right_motor) & MOTOR_RUNNING));
				}

				//Stop the movement of whichever motor was running forever
				ev3_command_motor_by_name(left_motor, COMMANDS_STRING[STOP]);
				ev3_command_motor_by_name(right_motor, COMMANDS_STRING[STOP]);
				sleep(1);
			}
			object_in_front = false;

			//Since motors stopped, set previous speed to run again.
			ev3_set_speed_sp (left_motor, speed_before_stopping + ADJUSTMENT);
			ev3_set_speed_sp (right_motor, speed_before_stopping);

		}

		//Set position to 0 for the following reverse.
		ev3_set_position_sp(right_motor, 0);
		ev3_set_position_sp(left_motor, 0);

		pthread_mutex_lock(&shared_data.mutex);
		last_button_pressed = shared_data.last_button_pressed;
		current_state = shared_data.catapult_state;
		pthread_mutex_unlock(&shared_data.mutex);

	}
	return NULL;
}

/**
 * Sensor thread.
 *
 * It gets data from the ultrasonic sensor and indicates whether something is ahead or not.
 */
void *sensor(void *arg) {
	struct sensor_thread_params params = *(struct sensor_thread_params*)arg;
	ev3_sensor_ptr ultrasonic_sensor = params.ultrasonic_sensor;
	int new_data;
	int last_button_pressed;
	bool object_in_front = false;

    //Open sensors
	ev3_open_sensor(ultrasonic_sensor);

    pthread_mutex_lock(&shared_data.mutex);
	last_button_pressed = shared_data.last_button_pressed;
	pthread_mutex_unlock(&shared_data.mutex);

    while(last_button_pressed != BUTTON_BACK) {
        ev3_update_sensor_val (ultrasonic_sensor);
        //Get the data from the ultrasonic sensor
        new_data = ultrasonic_sensor->val_data[0].s32;
    	object_in_front = false;
    	//If data is too close, something is ahead.
        if(new_data < 100)
        	object_in_front = true;

        pthread_mutex_lock(&shared_data.mutex);
		shared_data.object_in_front = object_in_front;
    	last_button_pressed = shared_data.last_button_pressed;
		pthread_mutex_unlock(&shared_data.mutex);
    }

    return NULL;
}

/**
 * Main function.
 *
 * Confirms all motors and sensors are connected to their ports.
 * Handles every thead
 */
int main(void) {
	ev3_sensor_ptr sensors       = NULL; //  List of available sensors
	ev3_sensor_ptr ultrasonic_sensor  = NULL;
	ev3_motor_ptr list_of_motors = NULL; // List of motors
	ev3_motor_ptr right_motor = NULL;
	ev3_motor_ptr left_motor = NULL;
	ev3_motor_ptr catapult_motor = NULL;

	pthread_mutexattr_t mutexattr;
    struct motors_thread_params motors_params;
    struct sensor_thread_params sensor_params;
	pthread_t buttons_thread,motors_thread, sensor_thread, screen_thread, state_thread;

	struct timespec screen_thread_period;

	//Initialize shared data
	pthread_mutex_lock(&shared_data.mutex);
	shared_data.start = false;
	shared_data.last_button_pressed = BUTTON_LEFT;
	shared_data.object_in_front = false;
	shared_data.attack_mode = true;
	shared_data.catapult_state = CHARGED;
	pthread_mutex_unlock(&shared_data.mutex);

	//Load motors
    list_of_motors = ev3_load_motors();
	if (list_of_motors == NULL) {
		printf ("Error on ev3_load_motors\n");
		return EXIT_FAILURE;
	}

	//Get port of each motor
	right_motor = ev3_search_motor_by_port (list_of_motors, RIGHT_MOTOR_PORT);
	left_motor = ev3_search_motor_by_port (list_of_motors, LEFT_MOTOR_PORT);
	catapult_motor = ev3_search_motor_by_port (list_of_motors, CATAPULT_MOTOR_PORT);
	if (left_motor == NULL || right_motor == NULL || catapult_motor == NULL) {
        printf ("Error on ev3_search_motor_by_port\n");
		return EXIT_FAILURE;
	}
	//Load all sensors
	sensors = ev3_load_sensors();
	if (sensors == NULL) {
		printf ("Error on ev3_load_sensors\n");
		return EXIT_FAILURE;
	}

	//Get port of each sensor
	ultrasonic_sensor = ev3_search_sensor_by_port (sensors, ULTRASONIC_SENSOR_PORT);
	if (ultrasonic_sensor == NULL) {
		printf ("Error on ev3_search_sensor_by_port\n");
		return EXIT_FAILURE;
	}

	screen_thread_period.tv_sec = 1;

	//Initialize mutex
	CHK( pthread_mutexattr_init (&mutexattr));
	CHK( pthread_mutexattr_setpshared(&mutexattr, PTHREAD_PROCESS_PRIVATE));
	CHK( pthread_mutexattr_setprotocol (&mutexattr, PTHREAD_PRIO_PROTECT));
	CHK( pthread_mutexattr_setprioceiling(&mutexattr, sched_get_priority_min(SCHED_RR)));
	CHK( pthread_mutex_init(&shared_data.mutex, &mutexattr));

	//Initialize structs
    motors_params.left_motor = left_motor;
    motors_params.right_motor = right_motor;
    motors_params.catapult_motor = catapult_motor;
    sensor_params.ultrasonic_sensor = ultrasonic_sensor;

	//Create Threads
	CHK (pthread_create(&screen_thread, NULL, screen, &screen_thread_period));
	printf("Screen thread created\n");
	CHK (pthread_create(&buttons_thread, NULL, buttons, NULL));
	printf("Buttons thread created\n");

	//Only screen and buttons work until user starts
	while(!shared_data.start);

	CHK (pthread_create(&motors_thread, NULL, motors, &motors_params));
	printf("Motors thread created\n");
	CHK (pthread_create(&sensor_thread, NULL, sensor, &sensor_params));
	printf("Sensor thread created\n");
	CHK (pthread_create(&state_thread, NULL, state, NULL));
	printf("State thread created\n");

	//Threads finish
	CHK (pthread_join(motors_thread, NULL));
	printf("Motors thread finished\n");
	CHK (pthread_join(buttons_thread, NULL));
	printf("Buttons thread finished\n");
	CHK (pthread_join(sensor_thread, NULL));
	printf("Sensor thread finished\n");
	CHK (pthread_join(screen_thread, NULL));
	printf("Screen thread finished\n");
	CHK (pthread_join(state_thread, NULL));
	printf("State thread finished\n");
	printf("\n***TODOS LOS HILOS TERMINADOS***\n");


	ev3_delete_motors(list_of_motors);
	ev3_delete_sensors(sensors);
	printf("FINAL\n");
	return 0;

}

/**
 * Indica qué boton se ha presionado.
 */
int is_button_pressed (void) {
    int button_pressed = -1;
    for(int i = 0; i <= 5; i++) {
    	if(ev3_button_pressed(i)) {
    		button_pressed = i;
    	}
    }
    return button_pressed;
}

/**
 * Actualiza la pantalla con nuevos datos.
 */
void update_screen(bool object_in_front, bool attack_mode, enum catapult_state current_state) {
	char object_detected [MAX_SIZE_BYTES];

	ev3_clear_lcd();
	display_exit_button();
	display_button_attack_mode(attack_mode);
	display_button_catapult(current_state);

}

void display_main_menu(void) {
	int last_button_pressed;
	bool start_button_hovered = true;
	bool no_options_selected = true;
	char button_start_text [MAX_SIZE_BYTES];
	sprintf (button_start_text, "Comenzar");
	char button_settings_text [MAX_SIZE_BYTES];
	sprintf (button_settings_text, "Ajustes");

	//Button Start
	ev3_text_lcd_small(EV3_X_LCD*30/100,EV3_Y_LCD*18/100,button_start_text);
	ev3_rectangle_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*25/100,EV3_X_LCD*56/100,EV3_Y_LCD*22/100,1);
	ev3_line_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*47/100,EV3_X_LCD*76/100,EV3_Y_LCD*47/100,1);
	ev3_line_lcd(EV3_X_LCD*76/100,EV3_Y_LCD*25/100,EV3_X_LCD*76/100,EV3_Y_LCD*47/100,1);

	//Button Settings
	ev3_text_lcd_small(EV3_X_LCD*30/100,EV3_Y_LCD*50/100,button_settings_text);
	ev3_rectangle_lcd_out(EV3_X_LCD*20/100,EV3_Y_LCD*58/100,EV3_X_LCD*56/100,EV3_Y_LCD*22/100,1);
	ev3_line_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*80/100,EV3_X_LCD*76/100,EV3_Y_LCD*80/100,1);
	ev3_line_lcd(EV3_X_LCD*76/100,EV3_Y_LCD*58/100,EV3_X_LCD*76/100,EV3_Y_LCD*80/100,1);

	while(no_options_selected) {
		pthread_mutex_lock(&shared_data.mutex);
		if(shared_data.last_button_pressed != -1 && last_button_pressed != shared_data.last_button_pressed)
			last_button_pressed = shared_data.last_button_pressed;
		pthread_mutex_unlock(&shared_data.mutex);
		if(last_button_pressed == BUTTON_UP && !start_button_hovered) {
			start_button_hovered = true;
			ev3_clear_lcd();
			ev3_text_lcd_small(EV3_X_LCD*30/100,EV3_Y_LCD*18/100,button_start_text);
			ev3_rectangle_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*25/100,EV3_X_LCD*56/100,EV3_Y_LCD*22/100,1);
			ev3_line_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*47/100,EV3_X_LCD*76/100,EV3_Y_LCD*47/100,1);
			ev3_line_lcd(EV3_X_LCD*76/100,EV3_Y_LCD*25/100,EV3_X_LCD*76/100,EV3_Y_LCD*47/100,1);
			ev3_rectangle_lcd_out(EV3_X_LCD*20/100,EV3_Y_LCD*58/100,EV3_X_LCD*56/100,EV3_Y_LCD*22/100,1);
			ev3_text_lcd_small(EV3_X_LCD*30/100,EV3_Y_LCD*50/100,button_settings_text);
			ev3_line_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*80/100,EV3_X_LCD*76/100,EV3_Y_LCD*80/100,1);
			ev3_line_lcd(EV3_X_LCD*76/100,EV3_Y_LCD*58/100,EV3_X_LCD*76/100,EV3_Y_LCD*80/100,1);
			sleep(1);
		}
		else if(last_button_pressed == BUTTON_DOWN && start_button_hovered) {
			start_button_hovered = false;
			ev3_clear_lcd();
			ev3_text_lcd_small(EV3_X_LCD*30/100,EV3_Y_LCD*18/100,button_start_text);
			ev3_rectangle_lcd_out(EV3_X_LCD*20/100,EV3_Y_LCD*25/100,EV3_X_LCD*56/100,EV3_Y_LCD*22/100,1);
			ev3_line_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*47/100,EV3_X_LCD*76/100,EV3_Y_LCD*47/100,1);
			ev3_line_lcd(EV3_X_LCD*76/100,EV3_Y_LCD*25/100,EV3_X_LCD*76/100,EV3_Y_LCD*47/100,1);
			ev3_text_lcd_small(EV3_X_LCD*30/100,EV3_Y_LCD*50/100,button_settings_text);
			ev3_rectangle_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*58/100,EV3_X_LCD*56/100,EV3_Y_LCD*22/100,1);
			ev3_line_lcd(EV3_X_LCD*20/100,EV3_Y_LCD*80/100,EV3_X_LCD*76/100,EV3_Y_LCD*80/100,1);
			ev3_line_lcd(EV3_X_LCD*76/100,EV3_Y_LCD*58/100,EV3_X_LCD*76/100,EV3_Y_LCD*80/100,1);
			sleep(1);
		}
		else if(last_button_pressed == BUTTON_CENTER && start_button_hovered) {
			no_options_selected = false;
			pthread_mutex_lock(&shared_data.mutex);
			shared_data.start = true;
			pthread_mutex_unlock(&shared_data.mutex);

		}
	}
}

void display_exit_button(void) {
	char button_back_text [MAX_SIZE_BYTES];
	sprintf(button_back_text, "Salir");
	//Exit Button
	ev3_text_lcd_small(EV3_X_LCD*3/100,EV3_Y_LCD*7/100,button_back_text);
	ev3_rectangle_lcd_out(EV3_X_LCD*2/100,EV3_Y_LCD*2/100,EV3_X_LCD*25/100,EV3_Y_LCD*15/100,1);
	ev3_line_lcd(EV3_X_LCD*2/100,EV3_Y_LCD*17/100,EV3_X_LCD*27/100,EV3_Y_LCD*17/100,1);
	ev3_line_lcd(EV3_X_LCD*27/100,EV3_Y_LCD*2/100,EV3_X_LCD*27/100,EV3_Y_LCD*17/100,1);
}

void display_button_attack_mode(bool on) {
	char button_attack_mode_text [MAX_SIZE_BYTES];
	sprintf(button_attack_mode_text, "Attack Mode OFF!");
	if(on)
		sprintf(button_attack_mode_text, "Attack Mode ON!");
	ev3_text_lcd_small(EV3_X_LCD*15/100,EV3_Y_LCD*85/100,button_attack_mode_text);
	ev3_rectangle_lcd_out(EV3_X_LCD*13/100,EV3_Y_LCD*80/100,EV3_X_LCD*74/100,EV3_Y_LCD*14/100,1);
	ev3_line_lcd(EV3_X_LCD*13/100,EV3_Y_LCD*94/100,EV3_X_LCD*87/100,EV3_Y_LCD*94/100,1);
	ev3_line_lcd(EV3_X_LCD*87/100,EV3_Y_LCD*80/100,EV3_X_LCD*87/100,EV3_Y_LCD*94/100,1);
}

void display_button_catapult(enum catapult_state current_state) {
	char button_catapult_ready_text [MAX_SIZE_BYTES];

	sprintf (button_catapult_ready_text, "Empty...");
	if(current_state == CHARGED)
		sprintf (button_catapult_ready_text, "Charged!");

	if(current_state == CHARGING) {
		//Text is a bit larger if charging. Fit it inside the box
		sprintf (button_catapult_ready_text, "Charging...");
		ev3_text_lcd_small(EV3_X_LCD*33/100,EV3_Y_LCD*7/100,button_catapult_ready_text);
	}
	else
		ev3_text_lcd_small(EV3_X_LCD*36/100,EV3_Y_LCD*7/100,button_catapult_ready_text);

	ev3_rectangle_lcd_out(EV3_X_LCD*32/100,EV3_Y_LCD*2/100,EV3_X_LCD*48/100,EV3_Y_LCD*15/100,1);
	ev3_line_lcd(EV3_X_LCD*32/100,EV3_Y_LCD*17/100,EV3_X_LCD*80/100,EV3_Y_LCD*17/100,1);
	ev3_line_lcd(EV3_X_LCD*80/100,EV3_Y_LCD*2/100,EV3_X_LCD*80/100,EV3_Y_LCD*17/100,1);

}

int get_random_num(void) {
	srand(time(0));
	return rand() % 2;
}
